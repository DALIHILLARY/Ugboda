<!-- Firstname Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('FirstName', 'Firstname:'); ?>

    <?php echo Form::text('FirstName', null, ['class' => 'form-control']); ?>

</div>

<!-- Lastname Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('LastName', 'Lastname:'); ?>

    <?php echo Form::text('LastName', null, ['class' => 'form-control']); ?>

</div>

<!-- District Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('District', 'District:'); ?>

    <?php echo Form::text('District', null, ['class' => 'form-control']); ?>

</div>

<!-- Plate Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('Plate', 'Plate:'); ?>

    <?php echo Form::text('Plate', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('riders.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH /home/hix/laraussd/Ugboda/resources/views/riders/fields.blade.php ENDPATH**/ ?>