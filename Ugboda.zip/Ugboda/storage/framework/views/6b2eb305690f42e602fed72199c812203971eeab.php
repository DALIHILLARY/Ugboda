<!-- Rider Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('rider', 'Rider:'); ?>

    <?php echo Form::number('rider', null, ['class' => 'form-control']); ?>

</div>

<!-- Phone Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('phone', 'Phone:'); ?>

    <?php echo Form::text('phone', null, ['class' => 'form-control']); ?>

</div>

<!-- Pin Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('pin', 'Pin:'); ?>

    <?php echo Form::text('pin', null, ['class' => 'form-control']); ?>

</div>

<!-- Active Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('active', 'Active:'); ?>

    <?php echo Form::text('active', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('phones.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH /home/hix/laraussd/Ugboda/resources/views/phones/fields.blade.php ENDPATH**/ ?>