<!-- Passphone Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('passPhone', 'Passphone:'); ?>

    <?php echo Form::text('passPhone', null, ['class' => 'form-control']); ?>

</div>

<!-- Riderphone Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('riderPhone', 'Riderphone:'); ?>

    <?php echo Form::text('riderPhone', null, ['class' => 'form-control']); ?>

</div>

<!-- Plate Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('plate', 'Plate:'); ?>

    <?php echo Form::text('plate', null, ['class' => 'form-control']); ?>

</div>

<!-- Approved Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('approved', 'Approved:'); ?>

    <?php echo Form::text('approved', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('logs.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH /home/hix/laraussd/Ugboda/resources/views/logs/fields.blade.php ENDPATH**/ ?>