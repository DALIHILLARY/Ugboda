<li class="<?php echo e(Request::is('riders*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('riders.index')); ?>"><i class="fa fa-edit"></i><span>Riders</span></a>
</li>

<li class="<?php echo e(Request::is('logs*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('logs.index')); ?>"><i class="fa fa-edit"></i><span>Logs</span></a>
</li>

<li class="<?php echo e(Request::is('phones*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('phones.index')); ?>"><i class="fa fa-edit"></i><span>Phones</span></a>
</li>

<li class="<?php echo e(Request::is('reports*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('reports.index')); ?>"><i class="fa fa-edit"></i><span>Reports</span></a>
</li>

<?php /**PATH /home/hix/laraussd/Ugboda/resources/views/layouts/menu.blade.php ENDPATH**/ ?>