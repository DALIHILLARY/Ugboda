<!-- Plate Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('plate', 'Plate:'); ?>

    <?php echo Form::text('plate', null, ['class' => 'form-control']); ?>

</div>

<!-- Phone Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('phone', 'Phone:'); ?>

    <?php echo Form::text('phone', null, ['class' => 'form-control']); ?>

</div>

<!-- Category Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('category', 'Category:'); ?>

    <?php echo Form::text('category', null, ['class' => 'form-control']); ?>

</div>

<!-- Riderid Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('riderId', 'Riderid:'); ?>

    <?php echo Form::number('riderId', null, ['class' => 'form-control']); ?>

</div>

<!-- Progress Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('progress', 'Progress:'); ?>

    <?php echo Form::text('progress', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('reports.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH /home/hix/laraussd/Ugboda/resources/views/reports/fields.blade.php ENDPATH**/ ?>