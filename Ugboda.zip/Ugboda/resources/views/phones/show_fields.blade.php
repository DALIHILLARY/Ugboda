<!-- Rider Field -->
<div class="form-group">
    {!! Form::label('rider', 'Rider:') !!}
    <p>{{ $phone->rider }}</p>
</div>

<!-- Phone Field -->
<div class="form-group">
    {!! Form::label('phone', 'Phone:') !!}
    <p>{{ $phone->phone }}</p>
</div>

<!-- Pin Field -->
<div class="form-group">
    {!! Form::label('pin', 'Pin:') !!}
    <p>{{ $phone->pin }}</p>
</div>

<!-- Active Field -->
<div class="form-group">
    {!! Form::label('active', 'Active:') !!}
    <p>{{ $phone->active }}</p>
</div>

