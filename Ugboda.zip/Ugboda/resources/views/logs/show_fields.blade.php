<!-- Passphone Field -->
<div class="form-group">
    {!! Form::label('passPhone', 'Passphone:') !!}
    <p>{{ $log->passPhone }}</p>
</div>

<!-- Riderphone Field -->
<div class="form-group">
    {!! Form::label('riderPhone', 'Riderphone:') !!}
    <p>{{ $log->riderPhone }}</p>
</div>

<!-- Plate Field -->
<div class="form-group">
    {!! Form::label('plate', 'Plate:') !!}
    <p>{{ $log->plate }}</p>
</div>

<!-- Approved Field -->
<div class="form-group">
    {!! Form::label('approved', 'Approved:') !!}
    <p>{{ $log->approved }}</p>
</div>

