<!-- Title Field -->
<div class="form-group">
    {!! Form::label('title', 'Title:') !!}
    <p>{{ $menu->title }}</p>
</div>

<!-- Isparent Field -->
<div class="form-group">
    {!! Form::label('isParent', 'Isparent:') !!}
    <p>{{ $menu->isParent }}</p>
</div>

